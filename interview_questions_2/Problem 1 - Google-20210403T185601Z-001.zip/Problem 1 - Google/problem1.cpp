#include <iostream>
#include <vector>
#include <unordered_set> 
#include <algorithm> // Sıralama algoritması için
#include <ctime>
#include <bits/stdc++.h> 


bool ikili_bul_1(int k, std::vector<int> array);
bool ikili_bul_vector(int k, std::vector<int> array);
bool ikili_bul_kume(int k, std::vector<int> array);
std::vector<int> generate_random_array(int size);

int main(){

    srand((unsigned)(time(0)));
    int k = rand()%10000 +1;

    std::vector<int> sayilar = generate_random_array(1000000);

    std::chrono::high_resolution_clock::time_point t1 = std::chrono::high_resolution_clock::now();
    //ikili_bul_1(k,sayilar);
    std::chrono::high_resolution_clock::time_point t2 = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>( t2 - t1 ).count();
    std::cout << "ikili_bul_1: " << duration << std::endl;
    
    t1 = std::chrono::high_resolution_clock::now();
    ikili_bul_kume(k,sayilar);
    t2 = std::chrono::high_resolution_clock::now();
    duration = std::chrono::duration_cast<std::chrono::microseconds>( t2 - t1 ).count();
    std::cout << "ikili_bul_kume: " << duration << std::endl;
    
    /*
    t1 = std::chrono::high_resolution_clock::now();
    ikili_bul_vector(k,sayilar);
    t2 = std::chrono::high_resolution_clock::now();
    duration = std::chrono::duration_cast<std::chrono::microseconds>( t2 - t1 ).count();
    std::cout << "ikili_bul_vector: " << duration << std::endl;
*/

    return 0;
}

bool ikili_bul_1(int k, std::vector<int> array){
    for(int i = 0; i<array.size()-1;i++){
        for(int j = i+1; j<array.size();j++){
            if (array[i] + array[j] == k){
                return true;
            }
        }
    }
    return false;
}

bool ikili_bul_vector(int k, std::vector<int> array){
    sort(array.begin(), array.end());

    int i,j, toplam;
    i = 0;
    j = array.size()-1;
    while(i != j){
        toplam = array[i] + array[j];
        if(toplam == k){
            return true;
        }
        else if(toplam > k){
            j--;
        }
        else{
            i++;
        }
    }
    return false;
}

bool ikili_bul_kume(int k, std::vector<int> array){
    std::unordered_set<int> tumleyen;
    for(int sayi : array){
        if(tumleyen.find(sayi) != tumleyen.end()){
            return true;
        }
        tumleyen.insert(k-sayi);
    }
    return false;
}


std::vector<int> generate_random_array(int size){
    srand((unsigned)(time(0)));
    int k = rand()%size +1;
    std::vector<int> array;
    for (int i = 0; i < size; i++){
        array.push_back(rand()%size + rand()%k);
        while(array[i] == 0){
            array[i] = rand()%size + rand()%k;
        }
    }
    return array;
}
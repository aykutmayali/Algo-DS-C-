#include <iostream>
#include <ctime>
#include <vector>
#include <bits/stdc++.h>

std::vector<int> bolme_ile(std::vector<int> sayilar);
std::vector<int> yurume_ile(std::vector<int> sayilar);
std::vector<int> generate_random_array(int size);


int main(){
    std::vector<int> sayilar =  generate_random_array(1000000);

    std::chrono::high_resolution_clock::time_point t1 = std::chrono::high_resolution_clock::now();
    std::vector<int> sonuc = bolme_ile(sayilar);
    std::chrono::high_resolution_clock::time_point t2 = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>( t2 - t1 ).count();
    std::cout << "bolme_ile: " <<duration << std::endl;

   
    t1 = std::chrono::high_resolution_clock::now();
    sonuc = yurume_ile(sayilar);
    t2 = std::chrono::high_resolution_clock::now();
    duration = std::chrono::duration_cast<std::chrono::microseconds>( t2 - t1 ).count();
    std::cout << "yurume_ile: " <<duration << std::endl;


    return 0;
}

std::vector<int> bolme_ile(std::vector<int> sayilar){
    std::vector<int> sonuc;
    int carpim = 1;

    for(int sayi: sayilar){
        carpim *= sayi;
    }

    for(int sayi: sayilar){
        sonuc.push_back(carpim/sayi);
    }

    return sonuc;
}

std::vector<int> yurume_ile(std::vector<int> sayilar){
    std::vector<int> sonuc(sayilar.size(),1);

    int sag,sol;
    int i,j;

    sol = 1;
    sag = 1;

    i = 1;
    j = sayilar.size() - 2;

    for(; i < sayilar.size(); i++, j--){
        sol *= sayilar[i-1];
        sag *= sayilar[j+1];

        sonuc[i] *= sol;
        sonuc[j] *= sag;
    }

    return sonuc;
}

std::vector<int> generate_random_array(int size){
    srand((unsigned)(time(0)));
    int k = rand()%size +1;
    std::vector<int> array;
    for (int i = 0; i < size; i++){
        array.push_back(rand()%size + rand()%k);
        while(array[i] == 0){
            array[i] = rand()%size + rand()%k;
        }
    }
    return array;
}
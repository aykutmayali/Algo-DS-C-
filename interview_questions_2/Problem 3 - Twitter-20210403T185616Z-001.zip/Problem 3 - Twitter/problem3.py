class SiparisKaydedici:

    def __init__(self,N):
        self.boyut = N
        self.siparis = []
        self.poz = 0

    def kaydet(self, siparis_id):
        if(len(self.siparis) < self.boyut):
            self.siparis.append(siparis_id)
        else:
            self.siparis[self.poz] = siparis_id
            self.poz = (self.poz + 1) % self.boyut
    
    def sondan(self,i):
        return self.siparis[ (self.poz - i) % self.boyut ]

    def __str__(self):
        return "{}".format(self.siparis)

siparisler = [1040,1050,1060,3040,5030,1020,1030,5001,5002,5003]
N = 4

sk = SiparisKaydedici(N)

for i,siparis in enumerate(siparisler):
    sk.kaydet(siparis)
    if(i>=N):
        print(sk,sk.sondan(2))
def dongu_ile(dizi):
    sonuc = [] 

    for i in range(len(dizi)):
        sayac = 0
        for j in range(i+1, len(dizi)):
            if(dizi[i] > dizi[j]):
                sayac += 1
        sonuc.append(sayac)
    return sonuc



class Dugum:
    def __init__(self,deger):
        self.deger = deger  
        self.sag = None
        self.sol = None

        self.tekrar = 1
        self.kucuk_sayisi = 0


class Agac:
    def __init__(self, dugum):
        self.kok = dugum

    def ekle(self, dugum):

        suan = self.kok # curr = self.root
        sayac = 0

        while(suan != None):
            onceki = suan

            if(dugum.deger > suan.deger):
                sayac += (suan.tekrar + suan.kucuk_sayisi)
                suan = suan.sag
            elif(dugum.deger < suan.deger):
                suan.kucuk_sayisi += 1
                suan = suan.sol
            else:
                onceki = suan
                onceki.tekrar+=1
                break
            
        if(dugum.deger > onceki.deger):
            onceki.sag = dugum
        elif(dugum.deger < onceki.deger):
            onceki.sol = dugum
        else:
            return sayac + onceki.kucuk_sayisi
        return sayac


if __name__ == "__main__":
    dizi = [3, 6, 9, 4, 1]

    #print(dongu_ile(dizi))

    agac = Agac(Dugum(dizi[-1]))
    sonuc = [0]

    for i in range(len(dizi)-2, -1, -1):
        eleman = Dugum(dizi[i])
        kucuk_sayisi = agac.ekle(eleman)
        sonuc.append(kucuk_sayisi)
    sonuc.reverse()
    print(sonuc)